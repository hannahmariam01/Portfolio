import './style.css'

const TAGS = ['Prompt Engineer','Web Developer','Product Thinking','React','AI Integration','Rapid Prototyping','HTML/CSS/JS']
const TAGS2 = ['Ship Fast','Prompt Well','Build Real','Think AI','No Fluff','Get Results']
const ticker = (arr) => [...arr,...arr].map(t=>`<span class="ti">${t}</span>`).join('')

document.querySelector('#app').innerHTML = `
<div id="pre">
  <div class="pre-name">${[...'HANNAH'].map((c,i)=>`<span class="c" style="animation-delay:${i*.07}s">${c}</span>`).join('')}</div>
  <div class="pre-bar"><div class="pre-fill" id="pf"></div></div>
  <div class="pre-pct" id="pp">0%</div>
</div>

<div id="cdot"></div>
<div id="cring"></div>

<nav id="nav">
  <a href="#" class="nl">HM©</a>
  <div class="nls"><a href="#about">About</a><a href="#work">Work</a><a href="#contact">Contact</a></div>
</nav>

<!-- Interactive Scroll Intro -->
<div class="scroll-intro-container" id="scroll-intro">
  <div class="scroll-intro-sticky">
    <canvas id="petal-canvas" style="position:absolute;inset:0;width:100%;height:100%;z-index:1;pointer-events:none;"></canvas>
    <div class="intro-sky"></div>
    <div class="intro-frame" id="intro-frame">
      <div class="intro-frame-top"></div>
      <div class="intro-frame-bottom"></div>
      <div class="intro-frame-left"></div>
      <div class="intro-frame-right"></div>
      <div class="intro-window-border"></div>
    </div>
    <div class="intro-text-1" id="intro-t1">
      <h2 class="intro-tag">SOFTWARE ENGINEER · WÜRZBURG, GERMANY</h2>
      <h1>I build digital products<br>by profession</h1>
      <p>professional overthinker when it comes to user experience.</p>
    </div>
    <div class="intro-text-2" id="intro-t2">
      <h1>From 0 to shipped — I build<br>products that stick</h1>
      <p>Thoughtful work, playful spirit</p>
    </div>
  </div>
</div>

<div class="stack-wrap">

<div class="panel" id="hero">
  <div class="blob b1"></div>
  <div class="blob b2"></div>
  <div class="blob b3"></div>
  <div class="sh sh-star" style="top:18%;left:12%;animation-duration:7s;">✦</div>
  <div class="sh sh-star" style="top:40%;right:8%;font-size:1.2rem;animation-duration:5s;color:#4361ee;">★</div>
  <div class="sh sh-ring" style="top:55%;left:6%;"></div>
  <div class="sh sh-sq" style="top:22%;right:22%;"></div>
  <div class="sh sh-dot" style="top:70%;right:30%;animation-delay:1s;"></div>
  <div class="sh sh-dot" style="top:15%;right:35%;animation-delay:2s;background:#7c3aed;width:8px;height:8px;"></div>
  <div class="sh sh-star" style="bottom:25%;left:35%;font-size:1.5rem;color:#00c9a7;animation-duration:6s;">◈</div>
  <canvas id="hc" style="position:absolute;inset:0;z-index:0;pointer-events:none;"></canvas>
  <div class="hero-mid">
    <p class="h-tag">AI Developer · Web Builder · Würzburg, Germany</p>
    <h1 class="h-name">
      <span class="hl"><span class="h-name-inner">HANNAH</span></span>
      <span class="hl"><span class="h-name-inner"><span class="accent">MARIAM</span></span></span>
    </h1>
    <div class="h-row">
      <p class="h-desc">I don't just <strong>use AI</strong> — I prompt it, chain it, and build <strong>real products</strong> with it.</p>
      <a href="#work" class="h-cta">See my work →</a>
    </div>
  </div>
</div>

<div class="panel" style="background:var(--ink);padding:1.5rem 0;min-height:unset;">
  <div class="ticker-track">${ticker(TAGS)}</div>
</div>

<div class="panel" id="about" style="background:var(--cream);">
  <div style="padding:7rem 5vw 8rem;">
  <div class="about-grid">
    <div>
      <div class="lbl sr">About Me</div>
      <h2 class="about-h sr d1">I build digital products<br>that solve <em>real</em> problems.</h2>
      <p class="about-p sr d2">I'm Hannah Mariam — a product-driven web developer focused on building scalable, user-centric tools. I bridge the gap between design and development to deliver digital products that feel effortless to use.</p>
      <p class="about-p sr d3">From government-scale data platforms to high-performance desktop apps and Figma plugins, I take ideas from concept to production, ensuring they are fast, functional, and ready to scale.</p>
      <div class="chips sr d4">
        ${['Web Developer','Frontend Development','Product Strategy','React / TS','Rapid Prototyping','UI / UX Integration'].map(t=>`<span class="chip"><span>${t}</span></span>`).join('')}
      </div>
    </div>
    <div class="stat-cards">
      <div class="scard sr d1"><div class="sc-n" data-count="4">0</div><div class="sc-t">Full products shipped — architecture to deployment</div></div>
      <div class="scard sr d2"><div class="sc-n">Impact</div><div class="sc-t">Focused on delivering tangible business value through robust code</div></div>
      <div class="scard sr d3"><div class="sc-n">0 Fluff</div><div class="sc-t">Just clean, pixel-perfect software that users actually love</div></div>
    </div>
  </div>
  </div>
</div>

<div class="panel" id="work" style="background:var(--cream2);">
  <div style="padding:8rem 0 8rem 5vw;">
  <div class="wh sr">
    <div><div class="lbl">Selected Work</div><div class="wh-title">What I've shipped</div></div>
    <div class="wh-ct">04</div>
  </div>
  <div class="hsx" id="hsx"><div class="hst" id="hst">
    <div class="pj" data-tilt data-casestudy="pd" style="cursor:pointer;">
      <div class="pj-top"><div class="pj-badge b-o">AI Tool</div><div class="pj-arr">→</div><img src="/pres-designer-preview.png" alt="Presentation Designer" draggable="false"></div>
      <div class="pj-body"><div class="pj-num">01</div><div class="pj-title">Presentation Designer</div><div class="pj-desc">Upload an existing document or PPT, get a Gravity brand-themed PPTX. AI-powered web app for automated brand formatting.</div><div class="pj-tags"><span class="pj-tag">Web App</span><span class="pj-tag">React</span><span class="pj-tag">OpenAI</span><span class="pj-tag">TS</span></div></div>
    </div>
    <div class="pj" data-tilt data-casestudy="rdg" style="cursor:pointer;">
      <div class="pj-top"><div class="pj-badge b-b">Web App</div><div class="pj-arr">→</div><img src="/rdg-preview.png" alt="RDG" draggable="false"></div>
      <div class="pj-body"><div class="pj-num">02</div><div class="pj-title">RDG</div><div class="pj-desc">Paste a URL — RDG analyses the live webpage and drops pixel-perfect editable screens straight into Figma.</div><div class="pj-tags"><span class="pj-tag">Web App</span><span class="pj-tag">React</span><span class="pj-tag">Figma API</span></div></div>
    </div>
    <div class="pj" data-tilt data-casestudy="fig" style="cursor:pointer;">
      <div class="pj-top"><div class="pj-badge b-p">Plugin</div><div class="pj-arr">→</div><img src="/figma-copilot-preview.png" alt="Fig Pilot" draggable="false"></div>
      <div class="pj-body"><div class="pj-num">03</div><div class="pj-title">Fig Pilot</div><div class="pj-desc">Figma plugin powered by Gemini. Turns frames to dark mode, exports to PPT, auto-layouts, and audits visuals.</div><div class="pj-tags"><span class="pj-tag">Plugin</span><span class="pj-tag">Gemini</span><span class="pj-tag">TS</span></div></div>
    </div>
    <div class="pj" data-tilt data-casestudy="doh" style="cursor:pointer;">
      <div class="pj-top"><div class="pj-badge b-g">Gov</div><div class="pj-arr">→</div><img src="/doh-preview.jpg" alt="DOH" draggable="false"></div>
      <div class="pj-body"><div class="pj-num">04</div><div class="pj-title">DOH</div><div class="pj-desc">Interactive policy landscape and design system for Australia's Dept of Health — mapping population groups to policies with an embedded guided tour.</div><div class="pj-tags"><span class="pj-tag">React 19</span><span class="pj-tag">TS</span><span class="pj-tag">Gov</span></div></div>
    </div>
  </div></div>
  <div class="sp" style="margin-right:5vw;"><div class="sb" id="sb"></div></div>
  </div>
  </div>

<div class="panel" id="process-panel" style="background:var(--cream2); padding:8rem 5vw;">
  <p class="gl-intro sr">My engineering <em>philosophy</em>.</p>
  <div class="acc-wrap sr d1">
    <div class="acc-row active">
      <div class="acc-head">
        <div class="acc-num">01</div>
        <div class="acc-title">Design-to-Code Alignment</div>
      </div>
      <div class="acc-body">
        <div class="acc-body-inner">
          <p>I don't just blindly translate static screens into code. I actively collaborate on the product's behavior, ensuring the technical architecture perfectly supports a seamless, high-performance user experience.</p>
          <img src="/phil_design.png" alt="Design to Code" class="acc-img" />
        </div>
      </div>
    </div>
    <div class="acc-row">
      <div class="acc-head">
        <div class="acc-num">02</div>
        <div class="acc-title">Scalable Foundations</div>
      </div>
      <div class="acc-body">
        <div class="acc-body-inner">
          <p>Every digital product needs a robust engine. Whether it's a lightweight Figma plugin or a complex government dashboard, I build clean, modular codebases focused on long-term maintainability.</p>
          <img src="/phil_scale.png" alt="Scalable Architecture" class="acc-img" />
        </div>
      </div>
    </div>
    <div class="acc-row">
      <div class="acc-head">
        <div class="acc-num">03</div>
        <div class="acc-title">Obsessive Polish</div>
      </div>
      <div class="acc-body">
        <div class="acc-body-inner">
          <p>A project isn't finished just because it "works." I obsess over the final 10% — the subtle state transitions, the load optimizations, and the micro-animations that turn a standard tool into a premium product.</p>
          <img src="/phil_polish.png" alt="Pixel Perfection" class="acc-img" />
        </div>
      </div>
    </div>
  </div>
</div>
<div class="panel" id="contact" style="background:var(--ink); display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; padding:8rem 5vw; position:relative; overflow:hidden;">
  <div class="ct-blob"></div>
  <p class="ct-pre sr">Open to new things</p>
  <h2 class="ct-h sr d1">LET'S<span>TALK.</span></h2>
  <p class="ct-p sr d2">Collaborations, freelance, full-time — I'm listening.</p>

  <div class="ct-cards sr d3">
    <a href="mailto:hannahmariam@email.com" class="ct-card">
      <div class="ct-card-icon">✉</div>
      <div class="ct-card-label">Email</div>
      <div class="ct-card-val">hannahmariam@email.com</div>
    </a>
    <a href="tel:+4915252790823" class="ct-card">
      <div class="ct-card-icon">📞</div>
      <div class="ct-card-label">Phone</div>
      <div class="ct-card-val">+49 1525 2790823</div>
    </a>
    <a href="https://linkedin.com/in/hannahmariam" target="_blank" rel="noopener" class="ct-card ct-card-blue">
      <div class="ct-card-icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>
      </div>
      <div class="ct-card-label">LinkedIn</div>
      <div class="ct-card-val">linkedin.com/in/hannahmariam ↗</div>
    </a>
    <a href="/resume.pdf" download class="ct-card ct-card-yellow">
      <div class="ct-card-icon">📄</div>
      <div class="ct-card-label">Resume</div>
      <div class="ct-card-val">Download CV ↓</div>
    </a>
  </div>

</div>

</div><!-- /stack-wrap -->

<!-- ═══════════════════════════════════════════
     CASE STUDY MODAL — DOH
═══════════════════════════════════════════ -->
<div class="cs-overlay" id="cs-doh" role="dialog" aria-modal="true" aria-label="DOH case study">
  <div class="cs-panel">
    <button class="cs-close" id="cs-close-doh" aria-label="Close case study">✕</button>
    <div class="cs-body">

      <!-- Hero -->
      <div class="cs-hero">
        <img src="/doh-preview.jpg" alt="DOH — Department of Health Australia" />
        <div class="cs-hero-overlay"></div>
        <div class="cs-hero-pill">
          <span class="cs-pill" style="background:#16a34a;color:#fff;">Interactive App</span>
          <span class="cs-pill">React 19 · TS</span>
          <span class="cs-pill">2025</span>
        </div>
      </div>

      <!-- Green header band -->
      <div class="doh-header">
        <div class="doh-gov-badge">🇦🇺 Australian Government</div>
        <div class="doh-header-content">
          <div>
            <div class="doh-eyebrow">Case Study · 04 · Interactive Policy Landscape</div>
            <h2 class="doh-title">Dept. of Health</h2>
            <p class="doh-tagline">Policy visualization. Population mapping. Interactive guided tours.</p>
          </div>
          <div class="doh-meta-pills">
            <span class="doh-pill">React 19</span>
            <span class="doh-pill">TypeScript</span>
            <span class="doh-pill">Tailwind CSS</span>
            <span class="doh-pill">2025</span>
          </div>
        </div>
      </div>

      <!-- Features KPI mockup -->
      <div class="doh-kpi-band">
        <div class="doh-kpi-label">Application modules</div>
        <div class="doh-kpi-grid">
          <div class="doh-kpi-card">
            <div class="doh-kpi-icon">🏔️</div>
            <div class="doh-kpi-n">Map</div>
            <div class="doh-kpi-l">Landscape View</div>
            <div class="doh-kpi-bar" style="--bw:100%"></div>
          </div>
          <div class="doh-kpi-card doh-kpi-card-hi">
            <div class="doh-kpi-icon">👥</div>
            <div class="doh-kpi-n">Groups</div>
            <div class="doh-kpi-l">Populations</div>
            <div class="doh-kpi-bar" style="--bw:100%"></div>
          </div>
          <div class="doh-kpi-card">
            <div class="doh-kpi-icon">🧭</div>
            <div class="doh-kpi-n">Tour</div>
            <div class="doh-kpi-l">Guided Prototype</div>
            <div class="doh-kpi-bar" style="--bw:100%"></div>
          </div>
          <div class="doh-kpi-card">
            <div class="doh-kpi-icon">🎨</div>
            <div class="doh-kpi-n">UI</div>
            <div class="doh-kpi-l">Design System</div>
            <div class="doh-kpi-bar" style="--bw:100%"></div>
          </div>
        </div>
      </div>

      <!-- Overview — white bg -->
      <div class="doh-overview">
        <div class="doh-overview-text">
          <p class="doh-section-label">The Vision</p>
          <h3 class="doh-overview-heading">Better health and wellbeing<br>for all Australians.</h3>
          <p class="doh-overview-body">Australia's Department of Health needed a modern way to communicate complex health policies and how they impact different population groups. Traditional documents were too dense to easily understand how policies map to the real world.</p>
        </div>
        <div class="doh-ps-col">
          <div class="doh-ps-card">
            <span class="doh-ps-icon">⚠️</span>
            <div>
              <strong>The Problem</strong>
              <p>Policy frameworks and population groups were disconnected in static documents, making it difficult for stakeholders to see the big picture.</p>
            </div>
          </div>
          <div class="doh-ps-card doh-ps-card-green">
            <span class="doh-ps-icon">✦</span>
            <div>
              <strong>The Solution</strong>
              <p>An interactive landscape visualization that maps policies to populations, complete with a guided Figma prototype tour and scalable design system.</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Hierarchy diagram -->
      <div class="doh-hierarchy">
        <p class="doh-section-label">Application Architecture</p>
        <h3 class="doh-hier-heading">Three core experiences. One platform.</h3>
        <div class="doh-hier-diagram">
          <div class="doh-tier doh-tier-fed">
            <div class="doh-tier-icon">🏔️</div>
            <div class="doh-tier-name">Interactive Landscape</div>
            <div class="doh-tier-desc">Visual mapping of health policies with clickable layers and popups</div>
          </div>
          <div class="doh-hier-arrow">→</div>
          <div class="doh-tier doh-tier-state">
            <div class="doh-tier-icon">🧭</div>
            <div class="doh-tier-name">Guided Tour</div>
            <div class="doh-tier-desc">Embedded Figma prototype viewer for interactive walkthroughs</div>
          </div>
          <div class="doh-hier-arrow">→</div>
          <div class="doh-tier doh-tier-local">
            <div class="doh-tier-icon">🎨</div>
            <div class="doh-tier-name">Design System</div>
            <div class="doh-tier-desc">Scalable component library built on Tailwind CSS and DaisyUI</div>
          </div>
        </div>
      </div>

      <!-- Features — green accent cards -->
      <div class="doh-features">
        <p class="doh-section-label">Key Features</p>
        <h3 class="doh-feat-heading">Built for policy visualization.</h3>
        <div class="doh-feat-grid">
          <div class="doh-feat-card">
            <div class="doh-feat-top"><span class="doh-feat-n">01</span><span class="doh-feat-emoji">🗺️</span></div>
            <h4>Interactive Mapping</h4>
            <p>Clickable landscape layers with distinct popups that reveal detailed policy information and system pressures.</p>
          </div>
          <div class="doh-feat-card doh-feat-card-green">
            <div class="doh-feat-top"><span class="doh-feat-n">02</span><span class="doh-feat-emoji">👥</span></div>
            <h4>Population Groups</h4>
            <p>Dedicated views detailing how policies affect specific demographics, highlighting equity and targeted support.</p>
          </div>
          <div class="doh-feat-card doh-feat-card-green">
            <div class="doh-feat-top"><span class="doh-feat-n">03</span><span class="doh-feat-emoji">🧭</span></div>
            <h4>Embedded Tours</h4>
            <p>Seamlessly integrated Figma prototype viewer (iframe) providing a guided tour of the DOH Policy directly in the app.</p>
          </div>
          <div class="doh-feat-card">
            <div class="doh-feat-top"><span class="doh-feat-n">04</span><span class="doh-feat-emoji">⚡</span></div>
            <h4>Modern Tech Stack</h4>
            <p>Built with React 19 and TypeScript, styled with Tailwind CSS, ensuring a fast, accessible, and maintainable codebase.</p>
          </div>
        </div>
      </div>

      <!-- Stack + Result -->
      <div class="doh-bottom">
        <div class="doh-stack-col">
          <p class="doh-section-label">Built With</p>
          <div class="doh-stack-list">
            <div class="doh-stack-row"><span class="doh-stack-dot" style="background:#61dafb"></span><span class="doh-stack-name">React 19</span><span class="doh-stack-role">UI framework</span></div>
            <div class="doh-stack-row"><span class="doh-stack-dot" style="background:#3178c6"></span><span class="doh-stack-name">TypeScript</span><span class="doh-stack-role">Type safety</span></div>
            <div class="doh-stack-row"><span class="doh-stack-dot" style="background:#38bdf8"></span><span class="doh-stack-name">Tailwind CSS</span><span class="doh-stack-role">Utility styling</span></div>
            <div class="doh-stack-row"><span class="doh-stack-dot" style="background:#ffd700"></span><span class="doh-stack-name">Vite</span><span class="doh-stack-role">Build tooling</span></div>
          </div>
        </div>
        <div class="doh-result-col">
          <div class="doh-result-big">1st</div>
          <div class="doh-result-sub">Interactive Policy Visualization</div>
          <p class="doh-result-body">By translating static policy frameworks into a digital landscape, stakeholders can now visually understand and navigate health policies, driving better health and wellbeing outcomes for all Australians.</p>
        </div>
      </div>

    </div><!-- /cs-body -->
  </div><!-- /cs-panel -->
</div><!-- /cs-overlay doh -->



<!-- ═══════════════════════════════════════════
     CASE STUDY MODAL — Presentation Designer
═══════════════════════════════════════════ -->
<div class="cs-overlay" id="cs-pd" role="dialog" aria-modal="true" aria-label="Presentation Designer case study">
  <div class="cs-panel">
    <button class="cs-close" id="cs-close-btn" aria-label="Close case study">✕</button>

    <!-- scrollable body -->
    <div class="cs-body">

      <!-- Hero image -->
      <div class="cs-hero">
        <img src="/pres-designer-preview.png" alt="Presentation Designer — Gravity Design System" />
        <div class="cs-hero-overlay"></div>
        <div class="cs-hero-pill">
          <span class="cs-pill coral">AI Tool</span>
          <span class="cs-pill">React · TypeScript</span>
          <span class="cs-pill">2025</span>
        </div>
      </div>

      <!-- Title block -->
      <div class="cs-content">
        <div class="cs-title-block">
          <div class="cs-eyebrow">Case Study · 01</div>
          <h2 class="cs-title">Presentation<br>Designer</h2>
          <div class="cs-meta-row">
            <div class="cs-meta"><span class="cs-meta-label">Type</span><span class="cs-meta-val">Web App</span></div>
            <div class="cs-meta"><span class="cs-meta-label">Stack</span><span class="cs-meta-val">React · TS · OpenAI</span></div>
            <div class="cs-meta"><span class="cs-meta-label">Template</span><span class="cs-meta-val">Gravity DS</span></div>
            <div class="cs-meta"><span class="cs-meta-label">Year</span><span class="cs-meta-val">2025</span></div>
          </div>
        </div>
      </div>

      <!-- ══ SECTION 1: Overview — coral bg ══ -->
      <div class="cs-section cs-s-coral">
        <div class="cs-s-deco cs-s-deco-ring"></div>
        <div class="cs-s-deco cs-s-deco-dot1"></div>
        <div class="cs-s-deco cs-s-deco-dot2"></div>
        <p class="cs-s-label">Overview</p>
        <h3 class="cs-s-heading">From raw docs<br>to Gravity PPT —<br><em>in under a minute.</em></h3>
        <p class="cs-s-body">Designers and marketers spend hours manually reformatting existing presentations to match the company's Gravity branding — fixing layouts, flipping colours, correcting inconsistencies slide by slide. Presentation Designer eliminates all of that. Upload your existing document or PPT, choose the Gravity template, and let OpenAI handle the rest.</p>
        <div class="cs-ps-grid">
          <div class="cs-ps-card">
            <div class="cs-ps-icon">⚠️</div>
            <h4>The Problem</h4>
            <p>Converting existing documents into on-brand PowerPoint files is tedious, error-prone, and kills momentum. Teams lose hours reformatting, switching modes, and auditing consistency slide by slide.</p>
          </div>
          <div class="cs-ps-card cs-ps-card-alt">
            <div class="cs-ps-icon">✦</div>
            <h4>The Solution</h4>
            <p>One tool that ingests your existing PPT or document and automates every painful step — content extraction, brand mapping, and layout standardisation — all in one pass.</p>
          </div>
        </div>
      </div>

      <!-- ══ SECTION 2: Workflow — cream bg, illustrated ══ -->
      <div class="cs-section cs-s-cream">
        <p class="cs-s-label cs-s-label-ink">My workflow for this project</p>
        <h3 class="cs-s-heading cs-s-heading-ink">Four steps.<br>Zero manual work.</h3>
        <div class="cs-flow">
          <div class="cs-flow-col">
            <div class="cs-flow-box">Upload<br>Doc/PPT</div>
            <div class="cs-flow-vline-wrap"><div class="cs-flow-vline"></div></div>
            <div class="cs-flow-node"><div class="cs-fn-inner">Drop your existing document or PowerPoint file — text, layout, and assets are parsed automatically.</div></div>
          </div>
          <div class="cs-flow-hconn"><div class="cs-flow-hline"></div></div>
          <div class="cs-flow-col">
            <div class="cs-flow-box cs-flow-box-hi">Apply<br>Template</div>
            <div class="cs-flow-vline-wrap"><div class="cs-flow-vline"></div></div>
            <div class="cs-flow-node cs-fn-offset"><div class="cs-fn-inner">Gravity design tokens applied — typography, colours, spacing locked to brand.</div></div>
          </div>
          <div class="cs-flow-hconn"><div class="cs-flow-hline cs-flow-hline-low"></div></div>
          <div class="cs-flow-col">
            <div class="cs-flow-box">AI<br>Processing</div>
            <div class="cs-flow-vline-wrap"><div class="cs-flow-vline"></div></div>
            <div class="cs-flow-node cs-fn-offset2"><div class="cs-fn-inner">OpenAI maps content to brand guidelines — typography rules, colour palettes, and structured layouts.</div></div>
          </div>
          <div class="cs-flow-hconn"><div class="cs-flow-hline cs-flow-hline-low2"></div></div>
          <div class="cs-flow-col">
            <div class="cs-flow-box">Export<br>PPTX</div>
            <div class="cs-flow-vline-wrap"><div class="cs-flow-vline"></div></div>
            <div class="cs-flow-node cs-fn-offset3"><div class="cs-fn-inner">Download pixel-perfect .pptx — ready to present, no edits needed.</div></div>
          </div>
        </div>
      </div>

      <!-- ══ SECTION 3: Features — dark bg ══ -->
      <div class="cs-section cs-s-dark">
        <div class="cs-s-deco cs-s-deco-ring cs-s-deco-ring-dark"></div>
        <p class="cs-s-label">What It Does</p>
        <h3 class="cs-s-heading">Four capabilities.<br>One tool.</h3>
        <div class="cs-feat-grid">
          <div class="cs-feat2">
            <div class="cs-feat2-top"><span class="cs-feat2-num">01</span><span class="cs-feat2-icon">📐</span></div>
            <h4>Doc to Brand PPT</h4>
            <p>Takes raw documents or PPTs and renders a fully structured PowerPoint, preserving content while mapping layouts and typography to the Gravity design system.</p>
            <div class="cs-feat2-bar" style="--bc:#ff5757"></div>
          </div>
          <div class="cs-feat2 cs-feat2-hi">
            <div class="cs-feat2-top"><span class="cs-feat2-num">02</span><span class="cs-feat2-icon">🎨</span></div>
            <h4>Intelligent Brand Mapping</h4>
            <p>The AI analyses raw text, colours, and fonts from your upload and maps them directly to the correct Gravity design system tokens automatically.</p>
            <div class="cs-feat2-bar" style="--bc:#4361ee"></div>
          </div>
          <div class="cs-feat2 cs-feat2-hi2">
            <div class="cs-feat2-top"><span class="cs-feat2-num">03</span><span class="cs-feat2-icon">📄</span></div>
            <h4>Content Extraction</h4>
            <p>Pulls out headings, bullet points, and images from messy, unformatted documents and restructures them cleanly for slide presentation.</p>
            <div class="cs-feat2-bar" style="--bc:#ffc947"></div>
          </div>
          <div class="cs-feat2">
            <div class="cs-feat2-top"><span class="cs-feat2-num">04</span><span class="cs-feat2-icon">📐</span></div>
            <h4>Layout Standardisation</h4>
            <p>Automatically fits your extracted content into pre-approved, professional Gravity slide templates, ensuring consistency across every deck.</p>
            <div class="cs-feat2-bar" style="--bc:#00c9a7"></div>
          </div>
        </div>
      </div>

      <!-- ══ SECTION 4: Tech — cream bg ══ -->
      <div class="cs-section cs-s-cream">
        <p class="cs-s-label cs-s-label-ink">Built With</p>
        <h3 class="cs-s-heading cs-s-heading-ink">The stack</h3>
        <div class="cs-tech-grid">
          <div class="cs-tech-item"><div class="cs-tech-dot" style="background:#61dafb"></div><div class="cs-tech-name">React</div><div class="cs-tech-role">UI framework</div></div>
          <div class="cs-tech-item"><div class="cs-tech-dot" style="background:#3178c6"></div><div class="cs-tech-name">TypeScript</div><div class="cs-tech-role">Type safety</div></div>
          <div class="cs-tech-item"><div class="cs-tech-dot" style="background:#10a37f"></div><div class="cs-tech-name">OpenAI API</div><div class="cs-tech-role">AI intelligence</div></div>
          <div class="cs-tech-item"><div class="cs-tech-dot" style="background:#ff5757"></div><div class="cs-tech-name">Gravity DS</div><div class="cs-tech-role">Design system</div></div>
          <div class="cs-tech-item"><div class="cs-tech-dot" style="background:#ffc947"></div><div class="cs-tech-name">pptxgenjs</div><div class="cs-tech-role">PPTX generation</div></div>
          <div class="cs-tech-item"><div class="cs-tech-dot" style="background:#7c3aed"></div><div class="cs-tech-name">Vite</div><div class="cs-tech-role">Build tool</div></div>
        </div>
      </div>

      <!-- ══ SECTION 5: Result — coral bg ══ -->
      <div class="cs-section cs-s-coral cs-s-result-strip">
        <div class="cs-s-deco cs-s-deco-sq1"></div>
        <div class="cs-s-deco cs-s-deco-sq2"></div>
        <div class="cs-result2-inner">
          <div class="cs-result2-stat">
            <div class="cs-result2-n">~95%</div>
            <div class="cs-result2-l">time saved per deck</div>
          </div>
          <div class="cs-result2-divider"></div>
          <div class="cs-result2-text">
            <h4>From raw docs to Gravity PPT in seconds</h4>
            <p>What used to take an afternoon of reformatting now takes under a minute. The AI ensures every slide perfectly matches the Gravity brand guidelines — every single time.</p>
          </div>
        </div>
      </div>

    </div><!-- /cs-body -->
  </div><!-- /cs-panel -->
</div><!-- /cs-overlay -->

<!-- ═══════════════════════════════════════════
     CASE STUDY MODAL — RDG
═══════════════════════════════════════════ -->
<style>
/* RDG uses white panel, Fig Pilot uses dark */
#cs-rdg .cs-panel {
  background: #fff;
}
#cs-fig .cs-panel {
  background: var(--ink);
}
/* RDG close button on white panel */
#cs-rdg .cs-close {
  background: rgba(26,18,37,.08);
  color: var(--ink);
  border: none;
}
#cs-rdg .cs-close:hover {
  background: var(--blue);
  color: #fff;
}
/* Fig Pilot close on dark panel */
#cs-fig .cs-close {
  background: rgba(255,255,255,.1);
  color: #fff;
  border: 1px solid rgba(255,255,255,.15);
}
#cs-fig .cs-close:hover {
  background: var(--blue);
  border-color: var(--blue);
}
</style>
<div class="cs-overlay" id="cs-rdg" role="dialog" aria-modal="true" aria-label="RDG case study">
  <div class="cs-panel">
    <button class="cs-close" id="cs-close-rdg" aria-label="Close case study">✕</button>
    <div class="cs-body">

      <!-- Hero -->
      <div class="cs-hero">
        <img src="/rdg-preview.png" alt="RDG — Rapid Design Generator" />
        <div class="cs-hero-overlay"></div>
        <div class="cs-hero-pill">
          <span class="cs-pill" style="background:var(--blue);color:#fff;">Web App</span>
          <span class="cs-pill">React · Figma API</span>
          <span class="cs-pill">2025</span>
        </div>
      </div>

      <!-- Blue accent header -->
      <div class="rdg2-header">
        <div class="rdg2-label">Case Study · 02</div>
        <div class="rdg2-title-row">
          <h2 class="rdg2-title">RDG</h2>
          <div class="rdg2-arrow">→</div>
          <div class="rdg2-figma">
            <span class="rdg2-figma-icon">🎨</span>
            <span>Figma</span>
          </div>
        </div>
        <p class="rdg2-sub">Rapid Design Generator · Paste a URL. Get editable Figma screens.</p>
      </div>

      <!-- URL graphic hero section -->
      <div class="rdg2-url-section">
        <div class="rdg2-url-display">
          <span class="rdg2-url-label">INPUT</span>
          <div class="rdg2-url-text">https://yoursite.com</div>
        </div>
        <div class="rdg2-arrow-big">→</div>
        <div class="rdg2-frames-display">
          <span class="rdg2-url-label">OUTPUT</span>
          <div class="rdg2-frames-row">
            <div class="rdg2-frame">Frame 1</div>
            <div class="rdg2-frame rdg2-frame-hi">Frame 2</div>
            <div class="rdg2-frame">Frame 3</div>
          </div>
          <div class="rdg2-frames-tag">Editable Figma frames</div>
        </div>
      </div>

      <!-- Overview text — white bg -->
      <div class="rdg2-overview">
        <div class="rdg2-overview-main">
          <p class="rdg2-section-label">The Problem &amp; Solution</p>
          <h3 class="rdg2-overview-heading">Any live webpage.<br>In Figma. Instantly.</h3>
          <p class="rdg2-overview-body">Rebuilding a live website in Figma from scratch takes hours of manual screenshotting, layer tracing, and component rebuilding. RDG eliminates all of it. Paste any live URL, and it analyses the page rapidly, then drops every screen as a fully editable Figma frame into your workspace.</p>
        </div>
        <div class="rdg2-two-col">
          <div class="rdg2-mini">
            <div class="rdg2-mini-icon">⚠️</div>
            <strong>The Problem</strong>
            <p>Hours of manual work to recreate any live page in Figma. No fast path from URL to editable design.</p>
          </div>
          <div class="rdg2-mini rdg2-mini-blue">
            <div class="rdg2-mini-icon">✦</div>
            <strong>The Solution</strong>
            <p>RDG scrapes, analyses, and reconstructs every screen as a pixel-faithful editable Figma frame.</p>
          </div>
        </div>
      </div>

      <!-- Features — 2x2 light cards -->
      <div class="rdg2-features">
        <p class="rdg2-section-label">What It Does</p>
        <h3 class="rdg2-feat-heading">Four steps. Zero manual work.</h3>
        <div class="rdg2-feat-grid">
          <div class="rdg2-feat-card">
            <div class="rdg2-feat-top"><span class="rdg2-feat-n">01</span><span class="rdg2-feat-emoji">🌐</span></div>
            <h4>Live URL Ingestion</h4>
            <p>Paste any live webpage URL. RDG fetches the page in real-time — no screenshots or manual input needed.</p>
            <div class="rdg2-feat-border" style="--bc:var(--blue)"></div>
          </div>
          <div class="rdg2-feat-card rdg2-feat-card-blue">
            <div class="rdg2-feat-top"><span class="rdg2-feat-n">02</span><span class="rdg2-feat-emoji">🔍</span></div>
            <h4>Rapid Page Analysis</h4>
            <p>Extracts layout, components, colours, typography and spacing from the live page automatically.</p>
            <div class="rdg2-feat-border" style="--bc:#fff"></div>
          </div>
          <div class="rdg2-feat-card">
            <div class="rdg2-feat-top"><span class="rdg2-feat-n">03</span><span class="rdg2-feat-emoji">🖼️</span></div>
            <h4>Pixel-Faithful Screens</h4>
            <p>Every screen is rebuilt exactly as it looks live — not approximated, fully reconstructed layer by layer.</p>
            <div class="rdg2-feat-border" style="--bc:var(--blue)"></div>
          </div>
          <div class="rdg2-feat-card rdg2-feat-card-blue">
            <div class="rdg2-feat-top"><span class="rdg2-feat-n">04</span><span class="rdg2-feat-emoji">✏️</span></div>
            <h4>Editable Figma Frames</h4>
            <p>Screens land as real editable Figma frames — not images or locked shapes. Ready to redesign or hand off.</p>
            <div class="rdg2-feat-border" style="--bc:#fff"></div>
          </div>
        </div>
      </div>

      <!-- Stack row — light -->
      <div class="rdg2-stack">
        <p class="rdg2-section-label">Built With</p>
        <div class="rdg2-stack-pills">
          <span class="rdg2-pill" style="--pc:#61dafb">React</span>
          <span class="rdg2-pill" style="--pc:#3178c6">TypeScript</span>
          <span class="rdg2-pill" style="--pc:#f24e1e">Figma API</span>
          <span class="rdg2-pill" style="--pc:#4361ee">AI (LLM)</span>
          <span class="rdg2-pill" style="--pc:#7c3aed">Vite</span>
          <span class="rdg2-pill" style="--pc:#00c9a7">REST API</span>
        </div>
      </div>

      <!-- Result banner — bold full-width blue -->
      <div class="rdg2-result">
        <div class="rdg2-result-stat">
          <div class="rdg2-result-n">0 min</div>
          <div class="rdg2-result-l">manual Figma rebuilding</div>
        </div>
        <div class="rdg2-result-text">
          <h4>Any live page. In Figma. Instantly.</h4>
          <p>What used to take hours of screenshotting and layer-tracing now takes a single URL paste. RDG doesn't speed up the process — it eliminates it.</p>
        </div>
      </div>

    </div><!-- /cs-body -->
  </div><!-- /cs-panel -->
</div><!-- /cs-overlay rdg -->


<!-- ═══════════════════════════════════════════
     CASE STUDY MODAL — FIG PILOT
═══════════════════════════════════════════ -->
<div class="cs-overlay" id="cs-fig" role="dialog" aria-modal="true" aria-label="Fig Pilot case study">
  <div class="cs-panel">
    <button class="cs-close" id="cs-close-fig" aria-label="Close case study">✕</button>
    <div class="cs-body">

      <!-- Hero -->
      <div class="cs-hero">
        <img src="/figma-copilot-preview.png" alt="Fig Pilot — Figma Plugin" />
        <div class="cs-hero-overlay"></div>
        <div class="cs-hero-pill">
          <span class="cs-pill" style="background:var(--purple);color:#fff;">Figma Plugin</span>
          <span class="cs-pill">React · Gemini API</span>
          <span class="cs-pill">2025</span>
        </div>
      </div>

      <!-- Plugin Header Band -->
      <div class="fp-header">
        <div class="fp-plugin-icon">✦</div>
        <div>
          <div class="fp-eyebrow">Case Study · 03 · Figma Plugin</div>
          <h2 class="fp-title">Fig Pilot</h2>
          <p class="fp-tagline">Your AI co-pilot, right inside Figma.</p>
        </div>
        <div class="fp-badge-col">
          <span class="fp-badge">Gemini Powered</span>
          <span class="fp-badge fp-badge-dim">2025</span>
        </div>
      </div>

      <!-- Split: sidebar plugin mockup + overview text -->
      <div class="fp-overview">
        <div class="fp-sidebar">
          <div class="fp-sidebar-label">Plugin sidebar</div>
          <div class="fp-cmd fp-cmd-active">🌙 Dark Mode</div>
          <div class="fp-cmd">📐 Export to PPT</div>
          <div class="fp-cmd">⚡ Auto Layout</div>
          <div class="fp-cmd">🔍 Visual Audit</div>
          <div class="fp-sidebar-hint">Select a frame, then run any command</div>
        </div>
        <div class="fp-overview-content">
          <p class="fp-section-label">What it does</p>
          <h3 class="fp-overview-heading">Four powerful tools.<br>One Figma sidebar.</h3>
          <p class="fp-overview-body">Designers waste hours on repetitive design ops — flipping colours for dark mode, snapping layers to Auto Layout, catching visual bugs, and exporting to client presentations. Fig Pilot puts a Gemini-powered assistant right in your Figma sidebar. Select a frame, pick a command, done.</p>
          <div class="fp-two-col">
            <div class="fp-mini-card">
              <span class="fp-mini-icon">⚠️</span>
              <div><strong>Problem</strong><p>Manual design polish drains creative energy — dark mode flips, layout fixes, inconsistency hunting, and PPT exports are all tedious, repetitive work.</p></div>
            </div>
            <div class="fp-mini-card">
              <span class="fp-mini-icon">✦</span>
              <div><strong>Solution</strong><p>A Figma plugin that automates all of it. Gemini analyses your selected frame and executes every operation in real-time with a single click.</p></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Commands grid — 2x2 large cards, purple accent -->
      <div class="fp-commands">
        <div class="fp-commands-header">
          <span class="fp-section-label">Commands</span>
          <h3 class="fp-commands-heading">Four capabilities. One plugin.</h3>
        </div>
        <div class="fp-cmd-grid">
          <div class="fp-cmd-card">
            <div class="fp-cmd-card-top">
              <span class="fp-cmd-num">01</span>
              <span class="fp-cmd-emoji">🌙</span>
            </div>
            <h4>Dark Mode Transform</h4>
            <p>One click remaps the frame into dark mode. Colours are swapped intelligently — not just inverted — keeping contrast and brand feel intact.</p>
            <div class="fp-cmd-accent" style="--ac:#4361ee"></div>
          </div>
          <div class="fp-cmd-card fp-cmd-card-hi">
            <div class="fp-cmd-card-top">
              <span class="fp-cmd-num">02</span>
              <span class="fp-cmd-emoji">📐</span>
            </div>
            <h4>Frame to PPT Export</h4>
            <p>Generates a fully structured, editable PowerPoint from your Figma frames — layout, type, and spacing preserved perfectly.</p>
            <div class="fp-cmd-accent" style="--ac:#7c3aed"></div>
          </div>
          <div class="fp-cmd-card">
            <div class="fp-cmd-card-top">
              <span class="fp-cmd-num">03</span>
              <span class="fp-cmd-emoji">⚡</span>
            </div>
            <h4>Auto Layout Engine</h4>
            <p>Messy absolute-positioned layers are automatically reflowed into proper Figma Auto Layout. No more manual nudging and grouping.</p>
            <div class="fp-cmd-accent" style="--ac:#ffc947"></div>
          </div>
          <div class="fp-cmd-card fp-cmd-card-hi">
            <div class="fp-cmd-card-top">
              <span class="fp-cmd-num">04</span>
              <span class="fp-cmd-emoji">🔍</span>
            </div>
            <h4>Visual Inconsistency Audit</h4>
            <p>Gemini scans the frame for design bugs — mismatched colours, off-brand fonts, misaligned elements — and returns a prioritised fix list.</p>
            <div class="fp-cmd-accent" style="--ac:#00c9a7"></div>
          </div>
        </div>
      </div>

      <!-- Stack + Result row -->
      <div class="fp-bottom">
        <div class="fp-stack-col">
          <span class="fp-section-label">Built With</span>
          <div class="fp-stack-list">
            <div class="fp-stack-row"><span class="fp-stack-dot" style="background:#61dafb"></span><span class="fp-stack-name">React</span><span class="fp-stack-role">UI framework</span></div>
            <div class="fp-stack-row"><span class="fp-stack-dot" style="background:#3178c6"></span><span class="fp-stack-name">TypeScript</span><span class="fp-stack-role">Type safety</span></div>
            <div class="fp-stack-row"><span class="fp-stack-dot" style="background:#f24e1e"></span><span class="fp-stack-name">Figma API</span><span class="fp-stack-role">Canvas manipulation</span></div>
            <div class="fp-stack-row"><span class="fp-stack-dot" style="background:#7c3aed"></span><span class="fp-stack-name">Gemini API</span><span class="fp-stack-role">AI intelligence</span></div>
            <div class="fp-stack-row"><span class="fp-stack-dot" style="background:#ffc947"></span><span class="fp-stack-name">pptxgenjs</span><span class="fp-stack-role">PPTX generation</span></div>
          </div>
        </div>
        <div class="fp-result-col">
          <div class="fp-result-big">90%</div>
          <div class="fp-result-sub">less manual design ops</div>
          <p class="fp-result-body">What used to take an afternoon of reformatting, auditing, and exporting now happens in seconds. Fig Pilot handles the busywork — you stay in the creative flow.</p>
          <div class="fp-result-quote">"Focus on design, not formatting."</div>
        </div>
      </div>

    </div><!-- /cs-body -->
  </div><!-- /cs-panel -->
</div><!-- /cs-overlay fig -->


`



// ── PRELOADER ──
const pf=document.getElementById('pf'),pp=document.getElementById('pp'),pre=document.getElementById('pre')
let pv=0; const pi=setInterval(()=>{pv+=Math.random()*16;if(pv>=100){pv=100;clearInterval(pi)}
pf.style.width=pv+'%';pp.textContent=Math.floor(pv)+'%'
if(pv===100)setTimeout(()=>{pre.classList.add('gone');document.getElementById('hero').classList.add('hero-loaded')},350)
},130)

// ── CURSOR ──
const dot=document.getElementById('cdot'),ring=document.getElementById('cring')
let mx=0,my=0,dx=0,dy=0,rx=0,ry=0
document.addEventListener('mousemove',e=>{mx=e.clientX;my=e.clientY})
;(function a(){dx+=(mx-dx)*.28;dy+=(my-dy)*.28;rx+=(mx-rx)*.1;ry+=(my-ry)*.1
dot.style.transform=`translate3d(${dx-5}px,${dy-5}px,0)`;ring.style.transform=`translate3d(${rx-19}px,${ry-19}px,0)`
requestAnimationFrame(a)})()
document.querySelectorAll('a,.chip,.pj,.li,.ct-btn,.h-cta').forEach(el=>{
  el.addEventListener('mouseenter',()=>document.body.classList.add('ca'))
  el.addEventListener('mouseleave',()=>document.body.classList.remove('ca'))
})

// ── NAV ──
const nav=document.getElementById('nav')
window.addEventListener('scroll',()=>nav.classList.toggle('st',scrollY>60),{passive:true})

// ── HERO CANVAS (optimised — no line drawing) ──
const cv=document.getElementById('hc'),cx=cv.getContext('2d')
const sz=()=>{cv.width=cv.offsetWidth;cv.height=cv.offsetHeight}; sz(); window.addEventListener('resize',sz)
const PCOLS=['#ff5757','#ffc947','#00c9a7','#4361ee','#f72585','#7c3aed']
// 28 particles max, no inter-particle lines (was O(n²) = main lag source)
const ps=[...Array(28)].map(()=>({x:Math.random()*1200,y:Math.random()*800,vx:(Math.random()-.5)*.25,vy:(Math.random()-.5)*.25,r:Math.random()*2.5+.8,a:Math.random()*.35+.1,col:PCOLS[Math.floor(Math.random()*PCOLS.length)]}))
let hmx=600,hmy=400; document.addEventListener('mousemove',e=>{hmx=e.clientX;hmy=e.clientY})
;(function dp(){
  cx.clearRect(0,0,cv.width,cv.height)
  ps.forEach(p=>{
    p.x+=p.vx+(hmx/cv.width-.5)*.2
    p.y+=p.vy+(hmy/cv.height-.5)*.2
    if(p.x<0)p.x=cv.width; if(p.x>cv.width)p.x=0
    if(p.y<0)p.y=cv.height; if(p.y>cv.height)p.y=0
    cx.beginPath();cx.arc(p.x,p.y,p.r,0,Math.PI*2)
    cx.fillStyle=p.col;cx.globalAlpha=p.a;cx.fill()
  })
  cx.globalAlpha=1;requestAnimationFrame(dp)
})()

// ── TEXT SCRAMBLE ──
const ABC='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
function scramble(el,final,delay){
  setTimeout(()=>{let i=0;const id=setInterval(()=>{el.textContent=final.split('').map((_,j)=>j<i?final[j]:ABC[Math.floor(Math.random()*26)]).join('');i+=.5;if(i>=final.length){el.textContent=final;clearInterval(id)}},40)},delay)
}
setTimeout(()=>document.querySelectorAll('.h-name-inner').forEach((el,i)=>scramble(el,el.textContent.trim(),2200+i*200)),100)

// ── SCROLL REVEAL ──
const sro=new IntersectionObserver(es=>{es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('v');sro.unobserve(e.target)}})},{threshold:.1,rootMargin:'0px 0px -40px 0px'})
document.querySelectorAll('.sr,.scard').forEach(el=>sro.observe(el))

// ── COUNTER ──
const cob=new IntersectionObserver(es=>{es.forEach(e=>{if(e.isIntersecting){const t=+e.target.dataset.count;let s=null;(function step(ts){if(!s)s=ts;const p=Math.min((ts-s)/1600,1);e.target.textContent=Math.floor(p*t);if(p<1)requestAnimationFrame(step);else e.target.textContent=t})(0);cob.unobserve(e.target)}})},{threshold:.5})
document.querySelectorAll('[data-count]').forEach(el=>cob.observe(el))

// ── HORIZONTAL SCROLL + PROGRESS ──
const hsx=document.getElementById('hsx'),sb=document.getElementById('sb')
let dr=false,sx=0,sl=0
hsx.addEventListener('mousedown',e=>{dr=true;sx=e.pageX-hsx.offsetLeft;sl=hsx.scrollLeft;hsx.style.cursor='grabbing'})
window.addEventListener('mouseup',()=>{dr=false;hsx.style.cursor='grab'})
hsx.addEventListener('mousemove',e=>{if(!dr)return;hsx.scrollLeft=sl-(e.pageX-hsx.offsetLeft-sx)*1.6})
hsx.addEventListener('scroll',()=>{sb.style.width=(hsx.scrollLeft/(hsx.scrollWidth-hsx.clientWidth)*100)+'%'},{passive:true})

// ── 3D TILT ──
document.querySelectorAll('[data-tilt]').forEach(c=>{
  c.addEventListener('mousemove',e=>{const r=c.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;c.style.transform=`perspective(900px) rotateY(${x*14}deg) rotateX(${-y*10}deg) translateY(-10px) rotate(-.5deg)`})
  c.addEventListener('mouseleave',()=>c.style.transform='')
})

// ── HOVER FLOAT IMAGE (removed due to redundant section) ──

// ── MAGNETIC ──
document.querySelectorAll('.ct-btn,.h-cta').forEach(b=>{
  b.addEventListener('mousemove',e=>{const r=b.getBoundingClientRect();b.style.transform=`translate(${(e.clientX-r.left-r.width/2)*.2}px,${(e.clientY-r.top-r.height/2)*.25}px) scale(1.07)`})
  b.addEventListener('mouseleave',()=>b.style.transform='')
})

// ── STACKING PANEL SCROLL (RAF-throttled, no blur) ──
;(()=>{
  const panels=[...document.querySelectorAll('.panel')]
  if(!panels.length)return

  // Fix for tall panels: calculate negative sticky top so they scroll fully before sticking
  function updateHeights(){
    const vh=window.innerHeight
    panels.forEach(panel=>{
      const ph=panel.offsetHeight
      panel.style.top = ph > vh ? `${vh - ph}px` : '0px'
    })
  }
  window.addEventListener('resize', updateHeights)
  // Need to wait for images/layout to settle
  setTimeout(updateHeights, 100)
  setTimeout(updateHeights, 1000)

  let ticking=false
  function update(){
    const vh=window.innerHeight
    panels.forEach((panel,i)=>{
      const next=panels[i+1]
      if(!next){
        panel.style.transform=''
        panel.style.opacity=''
        return
      }
      const pTop=panel.getBoundingClientRect().top
      const nTop=next.getBoundingClientRect().top
      // overlap: 0 = next not yet visible, 1 = next fully covers panel
      const overlap=Math.max(0,Math.min(1,1-nTop/vh))
      
      // If panel's native top matches its bounding rect top, it means it's actively sticking
      // We check if it is actively stuck or being pushed up
      const isStickingOrAbove = pTop <= parseInt(panel.style.top || '0') + 5
      
      if(isStickingOrAbove && nTop<=vh){
        // scale + opacity only — NO blur (blur = GPU kill)
        panel.style.transform=`scale(${1-overlap*.055}) translateZ(0)`
        panel.style.opacity=`${1-overlap*.38}`
      } else {
        panel.style.transform='translateZ(0)'
        panel.style.opacity=''
      }
    })
    ticking=false
  }
  window.addEventListener('scroll',()=>{
    if(!ticking){requestAnimationFrame(update);ticking=true}
  },{passive:true})
  update()
})()

// ── ACCORDION ──
document.querySelectorAll('.acc-row').forEach(row=>{
  row.addEventListener('mouseenter',()=>{
    document.querySelectorAll('.acc-row').forEach(r=>r.classList.remove('active'))
    row.classList.add('active')
  })
})

// ── CASE STUDY MODAL ──
;(()=>{
  const overlay = document.getElementById('cs-pd')
  const closeBtn = document.getElementById('cs-close-btn')
  const body = document.body

  function openModal(){
    overlay.classList.add('open')
    body.style.overflow = 'hidden'
    // scroll to top of cs-body each time
    overlay.querySelector('.cs-body').scrollTop = 0
  }

  function closeModal(){
    overlay.classList.remove('open')
    body.style.overflow = ''
  }

  // Open on clicking the Presentation Designer card
  document.querySelectorAll('[data-casestudy="pd"]').forEach(card=>{
    card.addEventListener('click', openModal)
  })

  // Close button
  closeBtn.addEventListener('click', closeModal)

  // Click outside panel closes modal
  overlay.addEventListener('click', e=>{
    if(e.target === overlay) closeModal()
  })

  // ESC key
  document.addEventListener('keydown', e=>{
    if(e.key === 'Escape' && overlay.classList.contains('open')) closeModal()
  })

  // Activate timeline dots sequentially as user scrolls the cs-body
  const csBody = overlay.querySelector('.cs-body')
  const tlItems = overlay.querySelectorAll('.cs-tl-item')
  csBody.addEventListener('scroll', ()=>{
    tlItems.forEach(item=>{
      const top = item.getBoundingClientRect().top
      if(top < window.innerHeight * 0.72) item.classList.add('active')
    })
  }, {passive: true})
})()

// ── RDG CASE STUDY MODAL ──
;(()=>{
  const overlay = document.getElementById('cs-rdg')
  const closeBtn = document.getElementById('cs-close-rdg')
  const body = document.body

  function openModal(){
    overlay.classList.add('open')
    body.style.overflow = 'hidden'
    overlay.querySelector('.cs-body').scrollTop = 0
  }
  function closeModal(){
    overlay.classList.remove('open')
    body.style.overflow = ''
  }

  document.querySelectorAll('[data-casestudy="rdg"]').forEach(card=>{
    card.addEventListener('click', openModal)
  })
  closeBtn.addEventListener('click', closeModal)
  overlay.addEventListener('click', e=>{
    if(e.target === overlay) closeModal()
  })
  document.addEventListener('keydown', e=>{
    if(e.key === 'Escape' && overlay.classList.contains('open')) closeModal()
  })
})()

// ── FIG PILOT CASE STUDY MODAL ──
;(()=>{
  const overlay = document.getElementById('cs-fig')
  const closeBtn = document.getElementById('cs-close-fig')
  const body = document.body

  function openModal(){
    overlay.classList.add('open')
    body.style.overflow = 'hidden'
    overlay.querySelector('.cs-body').scrollTop = 0
  }
  function closeModal(){
    overlay.classList.remove('open')
    body.style.overflow = ''
  }

  document.querySelectorAll('[data-casestudy="fig"]').forEach(card=>{
    card.addEventListener('click', openModal)
  })
  closeBtn.addEventListener('click', closeModal)
  overlay.addEventListener('click', e=>{
    if(e.target === overlay) closeModal()
  })
  document.addEventListener('keydown', e=>{
    if(e.key === 'Escape' && overlay.classList.contains('open')) closeModal()
  })
})()// ── DOH CASE STUDY MODAL ──
;(()=>{
  const overlay = document.getElementById('cs-doh')
  const closeBtn = document.getElementById('cs-close-doh')
  const body = document.body

  function openModal(){
    overlay.classList.add('open')
    body.style.overflow = 'hidden'
    overlay.querySelector('.cs-body').scrollTop = 0
  }
  function closeModal(){
    overlay.classList.remove('open')
    body.style.overflow = ''
  }

  document.querySelectorAll('[data-casestudy="doh"]').forEach(card=>{
    card.addEventListener('click', openModal)
  })
  closeBtn.addEventListener('click', closeModal)
  overlay.addEventListener('click', e=>{
    if(e.target === overlay) closeModal()
  })
  document.addEventListener('keydown', e=>{
    if(e.key === 'Escape' && overlay.classList.contains('open')) closeModal()
  })
})()

// ── SCROLL INTRO ──
(()=>{
  const container = document.getElementById('scroll-intro');
  const frame     = document.getElementById('intro-frame');
  const t1        = document.getElementById('intro-t1');
  const t2        = document.getElementById('intro-t2');
  if(!container || !frame) return;

  // Petal animation
  const canvas = document.getElementById('petal-canvas');
  const ctx = canvas.getContext('2d');
  const petals = [];
  const PETAL_COLORS = ['#ff9bb3','#ffb347','#ffd6e0','#ffc947','#e0c3fc'];
  function resizeCanvas(){
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);
  for(let i=0;i<32;i++){
    petals.push({
      x: Math.random()*window.innerWidth,
      y: Math.random()*window.innerHeight,
      r: 4+Math.random()*6,
      vx: -0.5+Math.random(),
      vy: 0.6+Math.random()*1.2,
      rot: Math.random()*Math.PI*2,
      vr: 0.02*(Math.random()-0.5),
      color: PETAL_COLORS[Math.floor(Math.random()*PETAL_COLORS.length)],
      opacity: 0.6+Math.random()*0.4
    });
  }
  function drawPetal(p){
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(p.rot);
    ctx.globalAlpha = p.opacity;
    ctx.beginPath();
    ctx.ellipse(0,0,p.r,p.r*1.6,0,0,Math.PI*2);
    ctx.fillStyle = p.color;
    ctx.fill();
    ctx.restore();
  }
  let petalVisible = true;
  function animatePetals(){
    if(!petalVisible){ requestAnimationFrame(animatePetals); return; }
    ctx.clearRect(0,0,canvas.width,canvas.height);
    for(const p of petals){
      p.x += p.vx; p.y += p.vy; p.rot += p.vr;
      if(p.y > canvas.height+20) { p.y=-20; p.x=Math.random()*canvas.width; }
      drawPetal(p);
    }
    requestAnimationFrame(animatePetals);
  }
  animatePetals();

  window.addEventListener('scroll', ()=>{
    const rect = container.getBoundingClientRect();
    if(rect.top > window.innerHeight || rect.bottom < 0) return;
    const maxScroll = rect.height - window.innerHeight;
    let p = 0;
    if(rect.top < 0) p = Math.min(1, Math.abs(rect.top) / maxScroll);

    // Phase 1 (0→0.5): frame scales up from 1→ ~10 (goes offscreen)
    if(p <= 0.5){
      const pp = p / 0.5;
      const scale = 1 + pp * 9; // 1 → 10
      frame.style.transform = `scale(${scale})`;
      t1.style.opacity = Math.max(0, 1 - pp * 2);
      t2.style.opacity = 0;
      petalVisible = true;
    }
    // Phase 2 (0.5→0.75): frame gone, text 2 fades in
    else if(p <= 0.75){
      const pp = (p - 0.5) / 0.25;
      frame.style.transform = `scale(10)`;
      t1.style.opacity = 0;
      t2.style.opacity = pp;
      t2.style.transform = `translateY(${(1-pp)*24}px)`;
    }
    // Phase 3 (0.75→1): hold
    else {
      frame.style.transform = `scale(10)`;
      t1.style.opacity = 0;
      t2.style.opacity = 1;
      t2.style.transform = `translateY(0)`;
    }
  });
})();
